<?php $__env->startSection('admin'); ?>
    <div class="page-content">

        <nav class="page-breadcrumb">
            <ol class="breadcrumb">
                <a href="<?php echo e(route('add.milestones')); ?>" class="btn btn-inverse-info"> Add Milestone </a>
            </ol>
        </nav>

        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">All Projects</h6>
                        <div class="table-responsive">
                            <table id="dataTableExample" class="table">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Milestone Name</th>
                                    <th>Start Date</th>
                                    <th>Due Date</th>
                                    <th>Project Name</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <?php $__currentLoopData = $milestones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tbody>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($item->milestone_name); ?></td>
                                        <td><?php echo e($item->milestone_start); ?></td>
                                        <td><?php echo e($item->milestone_end); ?></td>
                                        <td><?php echo e($item->milestone_projectId); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('edit.milestones', $item->id)); ?>" class="btn btn-inverse-warning"> Edit </a>
                                            <a href="<?php echo e(route('delete.milestones', $item->id)); ?>" class="btn btn-inverse-danger" id="delete"> Delete </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\overview-imanager-v5\resources\views/admin/milestones/all_milestones.blade.php ENDPATH**/ ?>