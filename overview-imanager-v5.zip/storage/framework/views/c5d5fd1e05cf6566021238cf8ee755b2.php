<?php $__env->startSection('admin'); ?>

    <div class="page-content">

        <nav class="page-breadcrumb">
            <ol class="breadcrumb">
                <a href="<?php echo e(route('add.service-type')); ?>" class="btn btn-inverse-info"> Add Service Type </a>
            </ol>
        </nav>

        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">All Service Types</h6>
                        <div class="table-responsive">
                            <table id="dataTableExample" class="table">
                                <thead>
                                <tr>
                                    <th>Serial Number</th>
                                    <th>Service Name</th>
                                    <th>Service Unit</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tbody>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($item->service_name); ?></td>
                                        <td><?php echo e($item->service_unit); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('edit.service-type', $item->id)); ?>" class="btn btn-inverse-warning"> Edit </a>
                                            <a href="<?php echo e(route('delete.service-type', $item->id)); ?>" class="btn btn-inverse-danger" id="delete"> Delete </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\overview-imanager-v5\resources\views/admin/services/all_service_type.blade.php ENDPATH**/ ?>