<?php $__env->startSection('admin'); ?>
    <div class="page-content">

        <nav class="page-breadcrumb">
            <ol class="breadcrumb">
                <a href="<?php echo e(route('add.clients')); ?>" class="btn btn-inverse-info"> Add Client </a>
            </ol>
        </nav>

        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">All Clients</h6>
                        <div class="table-responsive">
                            <table id="dataTableExample" class="table">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Telephone</th>
                                    <th>Address</th>
                                    <th>Company</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tbody>
                                    <tr>

                                        <td><?php echo e($item->client_name); ?></td>
                                        <td><?php echo e($item->client_email); ?></td>
                                        <td><?php echo e($item->client_telephone); ?></td>
                                        <td><?php echo e($item->client_address); ?></td>
                                        <td><?php echo e($item->client_pj_name); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('edit.service-type', $item->id)); ?>" class="btn btn-inverse-warning"> Edit </a>
                                            <a href="<?php echo e(route('delete.service-type', $item->id)); ?>" class="btn btn-inverse-danger" id="delete"> Delete </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\overview-imanager-v5\resources\views\admin\clients\all_clients.blade.php ENDPATH**/ ?>