@extends('admin.index')

@section('gantt')

    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h6 class="card-title">Gantt Chart</h6>
            </div>
        </div>
    </div>
@endsection
