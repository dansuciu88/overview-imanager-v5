// export default {
module.exports = {
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
    },
};
