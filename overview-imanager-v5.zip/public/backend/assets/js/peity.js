// npm package: peity
// github link: https://github.com/benpickles/peity

$(function() {
  'use strict'

  $('.peity-line').peity("line");
  $('.peity-bar').peity("bar");
  $('.peity-pie').peity("pie");
  $('.peity-donut').peity("donut");
  $('.peity-custom span').peity("donut");

});